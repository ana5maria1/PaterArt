let btnmenu = document.getElementById("btnmenu");
let menu = document.getElementById("menu");
btnmenu.addEventListener("click", function(){
     "use strict";
    menu.classList.toggle("mostrar");
                         });
